# GD Demon List

Це простий сайт на Flask, який відображає список демон-рівнів із Geometry Dash.

## 🔧 Технології:
- Python + Flask
- HTML + CSS

## ▶️ Запуск локально:
```
pip install flask
python main.py
```

## 🌐 Хостинг:
Готово для Render або Replit.
